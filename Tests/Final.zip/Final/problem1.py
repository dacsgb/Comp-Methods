import LSF_class
import numpy as np
import matplotlib.pyplot as plt

NonLin = LSF_class.NLCF('Tests\Final\sos2.txt')
NonLin.yes()
NonLin.Plot()
NonLin.Coeff()