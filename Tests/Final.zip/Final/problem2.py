import numpy as np
import scipy.integrate.quadpack as quad
import scipy.optimize as opt

import matplotlib.pyplot as plt

def sys(t,C):
    return C[0] + ( C[1]*np.exp(-C[2]*t)*np.sin(C[3]*t + C[4]))

def deriv(t,C):
    return C[1]*np.exp(-C[2]*t)*( C[3]*np.cos(C[3]*t + C[4]) - C[2]*np.sin(C[3]*t+C[4]))

def integral(t,C):
    return abs(( C[1]*np.exp(-C[2]*t)*np.sin(C[3]*t + C[4])))

def secondOrderSys(C,t_span):
    t_guess = (t_span[0]+t_span[1])/2
    sol = opt.fsolve(deriv,t_guess,args=(C))
    err = quad.quad(integral,t_span[0],t_span[1],args=(C))
    print('Peak location: t = {:.3f}'.format(sol[0]))
    print('Peak value: x = {:.3f}'.format(sys(sol,C)[0]))
    print('Error integral: err = {:.3f}'.format(err[0]))

C = [-0.5, -4, 0.55, 0.85, 0.1]
t = [0,15]

secondOrderSys(C,t)


